export * from './Detail';
